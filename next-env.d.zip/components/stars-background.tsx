"use client";

import { useEffect, useState } from 'react';

// ── ✏️ Shooting star config ──────────────────────────────────
// Each entry gets its own brand colour and a glowing tail.
const SHOOTS = [
  { label: "AWS",        color: "#FF9900", glow: "rgba(255,153,0,0.5)"   },
  { label: "Databricks", color: "#FF3621", glow: "rgba(255,54,33,0.5)"   },
  { label: "Docker",     color: "#2496ED", glow: "rgba(36,150,237,0.5)"  },
  { label: "Kubernetes", color: "#326CE5", glow: "rgba(50,108,229,0.5)"  },
  { label: "CI/CD",      color: "#FC6D26", glow: "rgba(252,109,38,0.5)"  },
  { label: "Azure",      color: "#0078D4", glow: "rgba(0,120,212,0.5)"   },
];

type Star = {
  id: number; top: number; left: number; size: number;
  duration: number; opacity: number; color: string;
};

type Shoot = {
  id: number; label: string; color: string; glow: string;
  startX: number; startY: number;
  delay: number; duration: number;
};

export function StarsBackground() {
  const [stars,  setStars]  = useState<Star[]>([]);
  const [shoots, setShoots] = useState<Shoot[]>([]);

  useEffect(() => {
    // Static star field
    const colors = ['#ffffff', '#e0f2fe', '#bae6fd', '#38bdf8', '#818cf8'];
    setStars(
      Array.from({ length: 250 }).map((_, i) => {
        const size = Math.random() * 2.5 + 0.5;
        return {
          id: i, size,
          top:      Math.random() * 100,
          left:     Math.random() * 100,
          duration: Math.random() * 4 + 2,
          opacity:  Math.random() * 0.8 + 0.2,
          color:    colors[Math.floor(Math.random() * colors.length)],
        };
      })
    );

    // Shooting stars — each fires independently, staggered 3 s apart
    setShoots(
      SHOOTS.map((s, i) => ({
        id:       i,
        label:    s.label,
        color:    s.color,
        glow:     s.glow,
        startX:   55 + Math.random() * 35,   // 55–90 vw
        startY:    5 + Math.random() * 35,   //  5–40 vh
        delay:    i * 4,                      // 4 s gap between each
        duration: 10 + Math.random() * 3,    // 10-13 s to cross screen (much slower)
      }))
    );
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 bg-[#040814]">

      {/* Nebula gradients */}
      <div className="absolute top-[-20%] left-[-10%] w-[70%] h-[70%] rounded-full bg-blue-900/20 blur-[130px] mix-blend-screen opacity-70 animate-pulse" style={{ animationDuration: '8s' }} />
      <div className="absolute bottom-[-20%] right-[-10%] w-[80%] h-[80%] rounded-full bg-indigo-900/15 blur-[150px] mix-blend-screen opacity-60 animate-pulse" style={{ animationDuration: '10s' }} />
      <div className="absolute top-[20%] left-[40%] w-[50%] h-[50%] rounded-full bg-emerald-900/10 blur-[120px] mix-blend-screen opacity-50 animate-pulse" style={{ animationDuration: '12s' }} />

      {/* Stars */}
      {stars.map((star) => (
        <div key={star.id} className="absolute rounded-full" style={{
          top: `${star.top}%`, left: `${star.left}%`,
          width: `${star.size}px`, height: `${star.size}px`,
          opacity: star.opacity, backgroundColor: star.color,
          animation: `twinkle ${star.duration}s infinite alternate ease-in-out`,
          boxShadow: `0 0 ${star.size + 2}px ${star.color}a0`,
        }} />
      ))}

      {/* Shooting stars — each has a real glowing tail + label */}
      {shoots.map((s) => (
        <div
          key={s.id}
          className="absolute"
          style={{
            left:    `${s.startX}vw`,
            top:     `${s.startY}vh`,
            opacity: 0,
            // The keyframe moves it diagonally and controls visibility.
            // animationDuration = full cycle so each label fires exactly
            // once per cycle, then waits for the others to fire too.
            animation:                `shoot ${s.duration}s linear ${s.delay}s infinite`,
            animationFillMode:        'forwards',
          }}
        >
          {/* Tail — a thin elongated gradient rotated -45° to match trajectory */}
          <div style={{
            position:     'absolute',
            right:        '100%',
            top:          '50%',
            transform:    'translateY(-50%) rotate(-45deg)',
            transformOrigin: 'right center',
            width:        '150px',
            height:       '2px',
            borderRadius: '9999px',
            background:   `linear-gradient(to right, transparent, ${s.color})`,
            boxShadow:    `0 0 6px 1px ${s.glow}`,
            filter:       'blur(0.5px)',
          }} />

          {/* Bright head dot */}
          <div style={{
            position:     'absolute',
            right:        'calc(100% - 4px)',
            top:          '50%',
            transform:    'translateY(-50%)',
            width:        '6px',
            height:       '6px',
            borderRadius: '50%',
            background:   '#ffffff',
            boxShadow:    `0 0 8px 3px ${s.glow}`,
          }} />

          {/* Label */}
          <span style={{
            fontFamily:    '"JetBrains Mono", "Fira Code", monospace',
            fontSize:      '13px',
            fontWeight:    600,
            letterSpacing: '0.07em',
            color:         '#ffffff',
            textShadow:    `0 0 10px ${s.color}`,
            whiteSpace:    'nowrap',
            background:    'rgba(10,16,31,0.85)',
            border:        `1px solid ${s.glow}`,
            padding:       '4px 10px',
            borderRadius:  '6px',
          }}>
            {s.label}
          </span>
        </div>
      ))}

      {/* Constellations */}
      <svg className="absolute inset-0 w-full h-full opacity-40">
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        <polyline points="15%,15% 22%,28% 28%,20% 40%,25% 48%,12%" fill="none" stroke="rgba(186,230,253,0.5)" strokeWidth="0.8" strokeDasharray="3 4" />
        <circle cx="15%" cy="15%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="22%" cy="28%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="28%" cy="20%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="40%" cy="25%" r="2.5" fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="48%" cy="12%" r="2"   fill="#ffffff" filter="url(#glow)"/>

        <polyline points="75%,60% 80%,65% 88%,60% 85%,50% 75%,55% 75%,60% 65%,45% 55%,38%" fill="none" stroke="rgba(186,230,253,0.4)" strokeWidth="0.8" strokeDasharray="3 4" />
        <circle cx="75%" cy="60%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="80%" cy="65%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="88%" cy="60%" r="2"   fill="#ffffff" filter="url(#glow)"/>
        <circle cx="85%" cy="50%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="75%" cy="55%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="65%" cy="45%" r="2.5" fill="#ffffff" filter="url(#glow)"/>
        <circle cx="55%" cy="38%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>

        <polyline points="10%,75% 15%,70% 30%,85% 35%,80% 45%,85% 30%,85%" fill="none" stroke="rgba(186,230,253,0.4)" strokeWidth="0.8" strokeDasharray="3 4" />
        <circle cx="10%" cy="75%" r="2"   fill="#ffffff" filter="url(#glow)"/>
        <circle cx="15%" cy="70%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="30%" cy="85%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="35%" cy="80%" r="2"   fill="#ffffff" filter="url(#glow)"/>
        <circle cx="45%" cy="85%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>

        <polyline points="80%,15% 90%,25% 85%,35% 70%,30% 80%,15%" fill="none" stroke="rgba(186,230,253,0.3)" strokeWidth="0.6" strokeDasharray="2 5" />
        <circle cx="80%" cy="15%" r="2"   fill="#ffffff" filter="url(#glow)"/>
        <circle cx="90%" cy="25%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
        <circle cx="85%" cy="35%" r="2.5" fill="#bae6fd" filter="url(#glow)"/>
        <circle cx="70%" cy="30%" r="2"   fill="#e0f2fe" filter="url(#glow)"/>
      </svg>

      <style>{`
        @keyframes twinkle {
          0%   { opacity: 0.1; transform: scale(0.6); }
          100% { opacity: 1;   transform: scale(1.4); }
        }

        /*
          shoot: fades in quickly, drifts slowly across, fades out at the end.
          The full duration IS the travel time (no shared-cycle trick).
          Repeats after a pause created by animationDelay on subsequent loops
          (CSS: delay only applies to the first cycle — subsequent cycles replay
          immediately, so labels naturally desync and feel random over time).
        */
        @keyframes shoot {
          0%   { opacity: 0;    transform: translate(0, 0); }
          6%   { opacity: 0.9; }
          88%  { opacity: 0.9; }
          100% { opacity: 0;    transform: translate(-110vw, 75vh); }
        }
      `}</style>
    </div>
  );
}
