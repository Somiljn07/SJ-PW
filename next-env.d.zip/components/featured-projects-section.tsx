"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"

// ============================================================
// Featured Projects Section — components/featured-projects-section.tsx
// ============================================================
// This section shows 2 highlighted projects on the homepage.
// For the full project list (4+ projects), see app/work/page.tsx.
//
// HOW TO UPDATE A PROJECT:
//   Edit any field in the `featuredProjects` array below.
//
// HOW TO SWAP WHICH PROJECTS ARE FEATURED:
//   1. Remove a project from this array.
//   2. Add its data to the `projects` array in app/work/page.tsx.
//   (Or vice-versa — keep this list to your 2 best/latest projects.)
//
// COLOUR OPTIONS for `color` field:  "indigo"  |  "cyan"
// ============================================================

// ── ✏️ EDIT YOUR FEATURED PROJECTS HERE ─────────────────────
const featuredProjects = [
  {
    index: "01",
    slug: "databricks-aws-private-connectivity",
    type: "Infrastructure",        // shown as the type badge
    title: "Databricks on AWS — End-to-End Private Connectivity",
    description: "Deployed a fully private Databricks workspace on AWS with zero public internet exposure. Configured VPC, PrivateLink, private endpoints, and IAM roles for a secure enterprise-grade data platform.",
    tags: ["Databricks", "AWS VPC", "PrivateLink", "IAM", "S3"],
    color: "indigo"
  },
  {
    index: "02",
    slug: "aws-landing-zone-multi-account",
    type: "Infrastructure",
    title: "AWS Landing Zone — Multi-Account Architecture",
    description: "Built an AWS Landing Zone from scratch using Control Tower. Established a multi-account structure with SCPs, guardrails, centralized logging, and account vending for enterprise governance at scale.",
    tags: ["Control Tower", "AWS Organizations", "SCPs", "CloudTrail", "IAM"],
    color: "cyan"
  }
]
// ────────────────────────────────────────────────────────────

export function FeaturedProjectsSection() {
  return (
    <section className="py-10 md:py-16 relative z-10">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10"
        >
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-8 bg-accent/60" />
              <span className="text-xs font-mono text-accent uppercase tracking-widest">Work</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
              Featured Work
            </h2>
            <p className="mt-3 text-muted-foreground">
              A selection of recent infrastructure projects
            </p>
          </div>
          <Link
            href="/work"
            className="group inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
          >
            View All Work
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </motion.div>

        {/* Project cards — auto-rendered from featuredProjects array above */}
        <div className="grid md:grid-cols-2 gap-6">
          {featuredProjects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              viewport={{ once: true }}
              className="h-full"
            >
              <article className="group relative h-full flex flex-col p-6 rounded-2xl border border-border/60 bg-[#0a101f]/80 hover:bg-[#0f172a] shadow-xl transition-all duration-300 border-glow overflow-hidden">
                {/* Large index number in background for visual depth */}
                <span className="absolute top-4 right-4 text-7xl font-black text-white/[0.03] select-none pointer-events-none leading-none">
                  {project.index}
                </span>

                {/* Type badge */}
                <div className="flex items-center justify-between mb-5">
                  <span className={`text-xs font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md ${
                    project.color === "indigo"
                      ? "bg-primary/10 text-primary/80"
                      : "bg-accent/10 text-accent/80"
                  }`}>
                    {project.type}
                  </span>
                </div>

                <h3 className="text-lg font-semibold text-foreground mb-3 leading-snug group-hover:text-primary transition-colors duration-200">
                  {project.title}
                </h3>

                <p className="text-gray-300 text-base leading-relaxed mb-6">
                  {project.description}
                </p>
                {/* Action button */}
                <div className="mb-6 mt-auto">
                  <Link 
                    href={`/work/${project.slug}`} 
                    className={`inline-flex items-center gap-1.5 text-xs font-semibold bg-transparent hover:bg-current/10 border-0 px-0 transition-colors ${
                      project.color === "indigo"
                        ? "text-primary/80"
                        : "text-accent/80"
                    }`}
                  >
                    View Details <ArrowRight size={13} />
                  </Link>
                </div>

                {/* Tech tags */}
                <div className="flex flex-wrap gap-1.5">
                  {project.tags.map((tag, i) => {
                    const colors = [
                      "bg-[#a855f7]/10 border-[#a855f7]/20 text-[#a855f7]",
                      "bg-primary/10 border-primary/20 text-primary",
                      "bg-[#ff9900]/10 border-[#ff9900]/20 text-[#ff9900]"
                    ];
                    return (
                      <span
                        key={tag}
                        className={`px-2.5 py-1 text-xs border rounded-lg ${colors[i % colors.length]}`}
                      >
                        {tag}
                      </span>
                    );
                  })}
                </div>
              </article>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
