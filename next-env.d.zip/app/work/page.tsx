"use client"

// ============================================================
// Work Page — app/work/page.tsx
// ============================================================
// HOW TO ADD A NEW PROJECT:
//   1. Add a new object to the `projects` array below.
//   2. The filter tabs update automatically based on the `type`
//      field — no other changes needed.
//
// FIELDS:
//   index        — display number e.g. "05" (keep sequential)
//   type         — "Infrastructure" | "Consulting" | "DevOps"
//                  (shows up in filter tabs automatically)
//   title        — project headline
//   description  — 2-3 sentence summary (no client names / NDA details)
//   highlights   — 3 bullet points shown in the expandable panel
//   tags         — tech keywords shown as chips
//   color        — "indigo" | "cyan" | "gold"
//
// HOW TO ADD A NEW FILTER TAB:
//   Add a new string to the `categories` array below and use
//   that same string as the `type` in any project object.
// ============================================================

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Navbar } from "@/components/navbar"
import { ScrollProgress } from "@/components/scroll-progress"
import { Footer } from "@/components/footer"
import { ArrowRight, ArrowUpRight } from "lucide-react"

// ── ✏️ ADD / REMOVE FILTER TABS HERE ────────────────────────
const categories = ["All", "Infrastructure", "Consulting", "DevOps"]

// ── ✏️ EDIT YOUR PROJECTS HERE ──────────────────────────────
export const projects = [
  {
    index: "01",
    slug: "databricks-aws-private-connectivity",
    type: "Infrastructure",
    title: "Databricks on AWS — End-to-End Private Connectivity",
    description: "Deployed a fully private Databricks workspace on AWS with zero public internet exposure. Configured VPC, PrivateLink, private endpoints, NAT Gateway configuration, and IAM roles for a secure enterprise-grade data platform. Achieved full network isolation while maintaining operability.",
    highlights: [
      "100% private — no public internet exposure",
      "PrivateLink for all Databricks backend communication",
      "Custom IAM roles with least-privilege access",
    ],
    tags: ["Databricks", "AWS VPC", "PrivateLink", "IAM", "S3", "NAT Gateway"],
    color: "indigo",
  },
  {
    index: "02",
    slug: "aws-well-architected-review",
    type: "Consulting",
    title: "AWS Well-Architected Review",
    description: "Analyzed a client's AWS environment against the Well-Architected Framework. Identified gaps across the 6 pillars — security, reliability, performance, cost optimization, sustainability, and operational excellence. Delivered a structured report with prioritized remediation recommendations.",
    highlights: [
      "Covered all 6 Well-Architected Framework pillars",
      "Identified 20+ actionable improvement areas",
      "Prioritized by impact and implementation effort",
    ],
    tags: ["AWS WAF", "Security", "Cost Optimization", "Architecture Review"],
    color: "gold",
  },
  {
    index: "03",
    slug: "aws-landing-zone-multi-account",
    type: "Infrastructure",
    title: "AWS Landing Zone — Multi-Account Architecture",
    description: "Built an AWS Landing Zone from scratch using Control Tower. Established a multi-account structure with SCPs, guardrails, centralized logging via CloudTrail, Security Hub, and account vending for enterprise governance at scale. Includes automated baseline account setup.",
    highlights: [
      "Multi-account structure with AWS Organizations",
      "Service Control Policies (SCPs) for governance",
      "Centralized logging & Security Hub integration",
    ],
    tags: ["Control Tower", "AWS Organizations", "SCPs", "CloudTrail", "IAM", "Security Hub"],
    color: "indigo",
  },
  {
    index: "04",
    slug: "databricks-cicd-asset-bundles",
    type: "DevOps",
    title: "Databricks CI/CD with Asset Bundles",
    description: "Set up CI/CD pipelines for Databricks using GitLab CI/CD and Databricks Asset Bundles. Automated deployment of notebooks, jobs, and clusters across dev/staging/prod environments for reliable, repeatable workflows. Eliminated manual deployment errors.",
    highlights: [
      "Automated multi-environment deployments",
      "Databricks Asset Bundles for infrastructure-as-code",
      "GitLab CI/CD with environment promotion gates",
    ],
    tags: ["Databricks Asset Bundles", "GitLab CI/CD", "Automation", "IaC"],
    color: "cyan",
  },
]

const colorMap: Record<string, { badge: string; glow: string; dot: string }> = {
  indigo: {
    badge: "bg-primary/10 text-primary/80 border-primary/20",
    glow: "group-hover:border-primary/40",
    dot: "bg-primary",
  },
  gold: {
    badge: "bg-[#f59e0b]/10 text-[#f59e0b]/80 border-[#f59e0b]/20",
    glow: "group-hover:border-[#f59e0b]/40",
    dot: "bg-[#f59e0b]",
  },
  cyan: {
    badge: "bg-accent/10 text-accent/80 border-accent/20",
    glow: "group-hover:border-accent/40",
    dot: "bg-accent",
  },
}

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const colors = colorMap[project.color] ?? colorMap.indigo

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.45, delay: index * 0.07 }}
      className="h-full"
    >
      <div className={`group rounded-2xl border border-border/60 bg-[#0a101f]/80 p-7 hover:bg-[#0f172a] shadow-xl transition-all duration-300 h-full flex flex-col ${colors.glow}`}>
        <div className="flex items-start justify-between gap-4 mb-5">
          <div className="flex items-center gap-3">
            <span className="text-3xl font-black text-muted-foreground/10 select-none font-mono leading-none">
              {project.index}
            </span>
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${colors.badge}`}>
              {project.type}
            </span>
          </div>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary transition-colors shrink-0 mt-1" />
        </div>

        <h3 className="text-xl font-bold text-foreground mb-3 leading-snug group-hover:text-primary transition-colors duration-200">
          {project.title}
        </h3>

        <p className="text-gray-300 text-base leading-relaxed mb-5">
          {project.description}
        </p>

        {/* Action button */}
        <div className="mb-6 mt-auto">
          <Link 
            href={`/work/${project.slug}`} 
            className={`inline-flex items-center gap-1.5 text-xs font-semibold ${colors.badge} bg-transparent hover:bg-current/10 border-0 px-0 transition-colors`}
          >
            View Details <ArrowRight size={13} />
          </Link>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className={`px-2.5 py-1 text-xs border rounded-lg ${colors.badge}`}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

export default function WorkPage() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filtered = activeCategory === "All"
    ? projects
    : projects.filter(p => p.type === activeCategory)

  return (
    <div className="min-h-screen relative">
      <div className="absolute inset-0 mesh-gradient pointer-events-none" />
      <ScrollProgress />
      <Navbar />
      <main className="relative pt-20 pb-12 px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="mb-16"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="h-px w-8 bg-primary/60" />
              <span className="text-xs font-mono text-primary uppercase tracking-widest">Portfolio</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground tracking-tight">
              Things I&apos;ve worked on
            </h1>
            <p className="mt-4 text-lg text-gray-300 max-w-2xl">
              Most of my work lives in client environments.
              I share context and approach without confidential details.
            </p>
          </motion.div>

          {/* Category filters */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="flex flex-wrap gap-2 mb-10"
          >
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 text-sm font-medium rounded-xl border transition-all duration-200 ${
                  activeCategory === cat
                    ? "bg-primary/15 border-primary/30 text-primary"
                    : "border-border/50 text-muted-foreground hover:text-foreground hover:border-border hover:bg-muted/20"
                }`}
              >
                {cat}
                <span className="ml-2 text-xs opacity-60">
                  {cat === "All" ? projects.length : projects.filter(p => p.type === cat).length}
                </span>
              </button>
            ))}
          </motion.div>

          <div className="grid md:grid-cols-2 gap-5">
            <AnimatePresence mode="popLayout">
              {filtered.map((project, index) => (
                <ProjectCard key={project.title} project={project} index={index} />
              ))}
            </AnimatePresence>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
