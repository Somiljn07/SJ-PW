# SJ Portfolio — Developer Guide

Personal portfolio website for Somil Jain, Cloud & DevOps Engineer.  
Built with **Next.js 15**, **Tailwind CSS v4**, and **Framer Motion**.

---

## 🚀 Running Locally

```bash
# Install dependencies (only needed once)
npm install

# Start the development server
npm run dev
```

Then open **http://localhost:3000** in your browser.  
The page hot-reloads instantly whenever you save a file.

---

## ✏️ How to Make Common Changes

### 1 — Publish a Blog Post

> File: `app/blog/page.tsx`

Find the `posts` array near the top of the file:

```ts
const posts = [
  {
    title: "Setting up an AWS Landing Zone...",
    category: "Cloud Infrastructure",
    readTime: "8 min",
    // href: "https://your-blog.com/aws-landing-zone",   ← uncomment & paste
  },
  ...
]
```

**To publish:** uncomment the `href` line and paste your post URL.  
The card automatically turns into a live, clickable link with a green badge.

**To add a new post:**
```ts
{
  title:    "Your post title",
  category: "Cloud Infrastructure",   // see categories below
  readTime: "7 min",
  href:     "https://...",            // omit if not published yet
},
```

Available categories (each has its own colour):  
`"Cloud Infrastructure"` `"Databricks"` `"Finance"` `"DevOps"`  
To add a new category, also add it to `categoryColors` in `components/blog/blog-card.tsx`.

---

### 2 — Add a New Skill / Technology

> File: `components/tech-stack-section.tsx`

Find the `techGroups` array. Each group has `items` (or `categories` for AWS):

**Add to an existing non-AWS group:**
```ts
{
  name: "DevOps & Automation",
  items: ["Terraform", "Docker", "YourNewTool"],  // ← just add here
}
```

**Add to an existing AWS category:**
```ts
{
  name: "Compute & Containers",
  items: ["EC2", "Lambda", "ECS", "EKS", "Fargate"],  // ← add here
}
```

**Add a new AWS category:**
```ts
{ name: "Machine Learning", items: ["SageMaker", "Bedrock"] }
```
Append to the `categories` array inside the `"AWS Cloud"` group.

**Add an entirely new skill group** (e.g. "Security Tools"):
```ts
{
  name: "Security Tools",
  description: "Exploring",
  color: "devops",     // "aws" | "databricks" | "devops" | "default"
  featured: false,     // false = smaller card below; true = large card on top
  items: ["Wiz", "Prisma Cloud"],
},
```

---

### 3 — Add a New Project

> File: `app/work/page.tsx`

Add a new object to the `projects` array:

```ts
{
  index: "05",                    // keep sequential
  type: "DevOps",                 // shows in filter tabs automatically
  title: "Your Project Title",
  description: "What you built and why it matters...",
  highlights: [
    "Key outcome 1",
    "Key outcome 2",
    "Key outcome 3",
  ],
  tags: ["Terraform", "AWS", "GitLab CI/CD"],
  color: "indigo",               // "indigo" | "cyan" | "gold"
},
```

To also show a project on the **homepage**, update `components/featured-projects-section.tsx`.

---

### 4 — Add a New Job / Role

> File: `components/about/experience-timeline.tsx`

Add a new object at the **top** of the `experiences` array (most recent first):

```ts
{
  index: "01",                    // renumber others below it
  role: "Senior Cloud Engineer",
  type: "Full-time",              // "Full-time" | "Trainee" | "Intern"
  company: "New Company",
  duration: "Jan 2026 – Present",
  points: [
    "What you worked on...",
    "Another key responsibility...",
  ],
  color: "indigo",               // "indigo" | "cyan" | "muted"
},
```

Remember to bump the `index` values of existing entries (01 → 02, 02 → 03, etc.).

---

### 5 — Add a Certification

> File: `components/about/certifications-grid.tsx`

Add a new object to the `certifications` array:

```ts
{
  name: "AWS Certified DevOps Engineer – Professional",
  issuer: "AWS",
  date: "Jun 2026",
  note: "CI/CD, infrastructure as code, monitoring",
  isPrimary: true,               // true = top row (larger); false = bottom row
  color: "#FF9900",              // "#FF9900" for AWS, "#0078D4" for Microsoft
},
```

---

### 6 — Update Personal Details

| What to change | File |
|----------------|------|
| Your name, title, description | `components/hero-section.tsx` |
| Bio text, the JSON fact card | `components/about/intro-section.tsx` |
| Social links (LinkedIn, GitHub) | `components/footer.tsx` → `socialLinks` |
| Contact page social links | `components/contact/contact-links.tsx` → `links` |
| Email address | `components/contact/contact-links.tsx` + `components/hero-section.tsx` |
| Education details | `components/about/education-section.tsx` |
| Interests / hobbies | `components/about/beyond-tech-section.tsx` → `interests` |

---

### 7 — Set Up the Contact Form

The contact form uses [Formspree](https://formspree.io) to receive emails without a backend.

1. Go to [formspree.io](https://formspree.io), sign up, create a form.
2. Copy your form ID (looks like `xabcdefg`).
3. Open `components/contact/contact-form.tsx` and update:

```ts
const FORMSPREE_URL = "https://formspree.io/f/YOUR_FORM_ID"
//                                                ^^^^^^^^^^^^^ replace this
```

---

## 🚢 Deploying to Vercel

**Option A — Git push (recommended):**
1. Push your code to GitHub.
2. Import the repo on [vercel.com](https://vercel.com).
3. Every `git push` to `main` auto-deploys.

**Option B — Vercel CLI:**
```bash
npm install -g vercel
vercel
```

---

## 📁 Key File Map

```
app/
  page.tsx                        ← Homepage
  about/page.tsx                  ← About page layout
  work/page.tsx                   ← ✏️ All projects + filter tabs
  blog/page.tsx                   ← ✏️ Blog posts list
  contact/page.tsx                ← Contact page layout

components/
  hero-section.tsx                ← ✏️ Name, title, stats, social links
  tech-stack-section.tsx          ← ✏️ All skills (AWS, Databricks, DevOps...)
  featured-projects-section.tsx   ← ✏️ 2 highlighted projects on homepage
  navbar.tsx                      ← Navigation bar
  footer.tsx                      ← ✏️ Social links, copyright

  about/
    intro-section.tsx             ← ✏️ Bio text, JSON fact card
    experience-timeline.tsx       ← ✏️ Work history
    certifications-grid.tsx       ← ✏️ Certifications
    education-section.tsx         ← ✏️ University, CGPA, awards
    beyond-tech-section.tsx       ← ✏️ Interests / hobbies

  contact/
    contact-form.tsx              ← ✏️ Formspree form ID goes here
    contact-links.tsx             ← ✏️ LinkedIn, GitHub, email

  blog/
    blog-card.tsx                 ← Blog row component (no editing needed)
```

`✏️` = files you'll edit most often.